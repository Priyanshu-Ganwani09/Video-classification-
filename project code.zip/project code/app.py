import streamlit as st
import numpy as np
import tensorflow as tf
import cv2
import random

def frames_extraction(video_path, num_frames, output_height, output_width, frame_step=15):
    frames = []
    cap = cv2.VideoCapture(video_path)
    video_length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    # Calculate the required starting frame based on the frame step
    max_start_frame = max(0, video_length - (num_frames - 1) * frame_step)
    start_frame = random.randint(0, max_start_frame)

    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)

    for _ in range(num_frames):
        ret, frame = cap.read()
        if ret:
            frame = cv2.resize(frame, (output_width, output_height))
            frames.append(frame)
        else:
            frames.append(np.zeros((output_height, output_width, 3)))  # Placeholder if frame is not available
        cap.set(cv2.CAP_PROP_POS_FRAMES, cap.get(cv2.CAP_PROP_POS_FRAMES) + frame_step - 1)

    cap.release()
    return np.array(frames)

def main():
    # Load your pre-trained model
    base_model = tf.keras.models.load_model('/content/ucf101_model.keras')  # Update the path as needed

    # Define the class labels
    CLASSES_LIST = ['ApplyLipstick', 'BalanceBeam', 'BabyCrawling', 'Archery', 'ApplyEyeMakeup'] 

    # Streamlit app
    st.title("Video Classification")

    # Upload video file
    uploaded_file = st.file_uploader("Choose a video...", type=["mp4", "avi", "mov"])

    if uploaded_file is not None:
        # Save the uploaded file temporarily
        with open("temp_video.mp4", "wb") as f:
            f.write(uploaded_file.read())

        # Extract frames
        frames = frames_extraction("temp_video.mp4", num_frames=10, output_height=224, output_width=224)
        frames_batch = np.expand_dims(frames, axis=0)

        # Make predictions
        predictions = base_model.predict(frames_batch)
        predicted_class_probs = predictions[0]
        predicted_class = CLASSES_LIST[np.argmax(predictions)]

        # Display results
        st.write(f"Predicted class: {predicted_class}")
        st.write("Class probabilities:")
        for idx, prob in enumerate(predicted_class_probs):
            st.write(f"{CLASSES_LIST[idx]}: {prob*100:.2f}%")

if __name__ == "__main__":
    main()
